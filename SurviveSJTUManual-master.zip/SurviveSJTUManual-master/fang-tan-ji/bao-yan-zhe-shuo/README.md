# 保研者说

我来说一下保研这条路。首先，路没有好坏之分，只有适不适合之别。不是说工作的人一定有闯劲，也不能说出国的人就一定有更光明的前途。

有个问题在一开始就要问自己：读研，是一条什么样的道路？

本部分经验分享统一转移至[https://survivesjtu.github.io/SJTU-Application/\#/](https://survivesjtu.github.io/SJTU-Application/#/)

